﻿using ePizzaHub.Entites;
using ePizzaHub.Repositiories.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
namespace ePizzaHub.Repositiories.Interfaces
{
   public interface IOrderRepository:IRepository<Order>
    {
        OrderModel GetOrderDetails(string orderId);

        IEnumerable<Order> GetUserOrder(int UserId);

        PagingListModel<OrderModel> GetOrderList(int page, int pageSize);
        

    }
}
