﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ePizzaHub.UI.Models
{
    public class UserModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage ="Please Enter Email ID")]
        [EmailAddress(ErrorMessage = "Invalid Email Id")]
        public string Email { get; set; }

        [Required(ErrorMessage ="Please Enter Name")]
        public string Name { get; set; }

        [Required(ErrorMessage ="Please Enter Password")]
        public string Password { get; set; }

        [Compare("Password",ErrorMessage ="Comapre Password doesnt Match")]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage ="Please Enter Phone Number")]
        public string PhoneNumber { get; set; }


    }
}
