﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ePizzaHub.UI.Models
{
    public class ItemModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage ="Please Enter Name")]
        public string Name { get; set; }


        public IFormFile File { get; set; }

        [Required(ErrorMessage ="Please Enter Description")]
        public string Descriptiom { get; set; }

        [Required(ErrorMessage ="Please Enter a Unit Price")]
        public decimal UnitPrice { get; set; }

        public string ImageUrl { get; set; }

        [Required(ErrorMessage = "Please Select a Category ID")]
        public int CategoryId { get; set; }

        [Required(ErrorMessage ="Please Select Item")]
        public int ItemTypeId { get; set; }


    }
}
