﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ePizzaHub.Entites;
using ePizzaHub.Services.Interface;
using ePizzaHub.UI.Models;
using Microsoft.AspNetCore.Mvc;

namespace ePizzaHub.UI.Controllers
{
    public class AccountController : Controller
    {
        IAuthenticationService _authService;
        public AccountController(IAuthenticationService authService)
        {
            _authService = authService;
        }
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginModel model, string returnurl)
        {
            var user = _authService.AuthenticateUser(model.Email, model.Password);
            if(user!=null)
            {
                if (!string.IsNullOrEmpty(returnurl))
                    return Redirect(returnurl);

                if (user.Role.Contains("Admin"))
                {
                    //For Adming Section and redirect to Admin Area
                    return RedirectToAction("Index", "Dashboard", new { area = "Admin" });
                }
                else if (user.Role.Contains("User"))
                {
                    return RedirectToAction("Index", "Dashboard", new { area = "User" });

                }

            }
            return View();
        }

        public IActionResult SignUp()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SignUp(UserModel model)
        {
            if (ModelState.IsValid)
            {
                User user = new User
                {
                    Name = model.Name,
                    UserName = model.Email,
                    Email = model.Email,
                    PhoneNumber = model.PhoneNumber
                };
                bool result = _authService.CreateUser(user, model.Password);
                if(result)
                {
                    return RedirectToAction("Login");
                }
              }
            return View();
        }

        public async Task <IActionResult> SignOut()
        {
            await _authService.SignOut();
            return RedirectToAction("SignOutComplete","Account");
        }
        public IActionResult SignOutComplete()
        {
            return View();

        }

        public IActionResult UnUnauthorize()
        {
            return View();
        }

    }
}
