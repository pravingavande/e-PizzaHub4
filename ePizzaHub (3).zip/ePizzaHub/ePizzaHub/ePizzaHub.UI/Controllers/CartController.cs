﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using ePizzaHub.Entites;
using ePizzaHub.Repositiories.Models;
using ePizzaHub.Services.Interface;
using ePizzaHub.UI.Helpers;
using Microsoft.AspNetCore.Mvc;

namespace ePizzaHub.UI.Controllers
{
    public class CartController : Controller
    {
        ICartService _cartService;
        IUserAccessor _userAccessor;
        public CartController(ICartService cartService, IUserAccessor userAccessor)
        {
            _cartService = cartService;
            _userAccessor = userAccessor;
        }

        public User CurrentUser { 
            get
            {
                if (User != null)
                    return _userAccessor.GetUser();
                else
                    return null;
            }
        }

        Guid CartId {
            get
            {
                Guid Id;
                string CId = Request.Cookies["CId"];
                if(string.IsNullOrEmpty(CId))
                {
                    Id = Guid.NewGuid();
                    Response.Cookies.Append("CId",Id.ToString());

                }
                else
                {
                    Id = Guid.Parse(CId);

                }
                return Id;

            }
        }


        public IActionResult Index()
        {
            CartModel cart = _cartService.GetCartDetail(CartId);
            if(CurrentUser !=null && cart !=null)
            {
                //TempData.ToHashSet("Cart", cart);
                TempData.Set("Cart", cart);
                _cartService.UpdateCart(cart.Id,CurrentUser.Id);
            }

            return View(cart);
        }

        [Route("Cart/AddToCart/{ItemId}/{UnitPrice}/{Quantity}")]
        public IActionResult AddToCart(int ItemId,decimal UnitPrice,int Quantity)
        {
            int UserId = CurrentUser != null ? CurrentUser.Id : 0;
            if(ItemId>0 && Quantity >0)
            {
                Cart cart = _cartService.AddItem(UserId, CartId, ItemId, UnitPrice, Quantity);
                var data = JsonSerializer.Serialize(cart);
                return Json(data);

            }
            else
            {
                return Json("");
            }
           
        }

        [Route("Cart/UpdateQuantity/{Id}/{Quantity}")]
        public IActionResult UpdateQuantity(int Id,int Quantity)
        {
            int count = _cartService.UpdateQuantity(CartId, Id, Quantity);
            return Json(count);

        }

        public IActionResult DeleteItem(int id)
        {
            int count = _cartService.DeleteItem(CartId, id);
            return Json(count);
        }

        public IActionResult GetCartCount()
        {
            int count = _cartService.GetCartCount(CartId);
            return Json(count);
        }


        public IActionResult CheckOut()
        {

            return View();
        }

        [HttpPost]
        public IActionResult CheckOut(Address address)
        {
            TempData.Set("Address", address);
          
//            TempData["Address"] = address;
            return RedirectToAction("Index","Payment");
        }
    }
}
