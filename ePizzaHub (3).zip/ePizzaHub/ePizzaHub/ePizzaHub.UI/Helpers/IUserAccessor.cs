﻿using ePizzaHub.Entites;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ePizzaHub.UI.Helpers
{
    public interface IUserAccessor
    {
        User GetUser();

    }
}
