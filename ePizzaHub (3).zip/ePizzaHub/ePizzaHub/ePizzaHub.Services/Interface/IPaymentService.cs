﻿using ePizzaHub.Entites;
using Razorpay.Api;
using System;
using System.Collections.Generic;
using System.Text;

namespace ePizzaHub.Services.Interface
{
   public interface IPaymentService
    {
        string CreateOrder(decimal amount, string currency, string receipt);

        string CapturePayment(string paymentId, string orderId);

        Payment GetPaymentDetails(string paymentId);
        bool VerifySignature(string signature, string orderId, string paymentId);
        int savepaymentdetails(PaymentDetails model);



    }
}
