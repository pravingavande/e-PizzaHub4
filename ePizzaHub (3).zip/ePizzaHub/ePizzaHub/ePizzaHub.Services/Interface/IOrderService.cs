﻿using ePizzaHub.Entites;
using ePizzaHub.Repositiories.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ePizzaHub.Services.Interface
{
   public interface IOrderService
    {
        OrderModel GetOrderDetails(string orderId);

        IEnumerable<Order> GetUserOrder(int UserId);

        PagingListModel<OrderModel> GetOrderList(int page=1, int pageSize=10);


        int PlaceOrder(int userId, string OrderId, string paymentId, CartModel cart, Address address);

    }
}
