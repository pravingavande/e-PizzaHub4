﻿using ePizzaHub.Entites;
using ePizzaHub.Repositiories.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ePizzaHub.Services.Interface
{
   public interface ICartService
    {
        int GetCartCount(Guid cartId);

        CartModel GetCartDetail(Guid cartId);

        Cart AddItem(int UserId,Guid CartId,int ItemId,decimal UnitPrice,int quantity);

        int DeleteItem(Guid cartId, int ItemId);

        int UpdateQuantity(Guid cartId, int Id, int quantity);

        int UpdateCart(Guid cartId,int UserId);



    }
}
