﻿using ePizzaHub.Entites;
using ePizzaHub.Repositiories.Models;
using ePizzaHub.Services.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
namespace ePizzaHub.Services.Implementation
{
    public class OrderService : IOrderService
    {


        private readonly IOrderService _orderRepo;

        public OrderService(IOrderService orderRepo)
        {
            _orderRepo = orderRepo;
        }

        public OrderModel GetOrderDetails(string orderId)
        {
            var model = _orderRepo.GetOrderDetails(orderId);
            if (model != null && model.Items.Count > 0)
            {
                decimal subtotal = 0;
                foreach (var item in model.Items)
                {
                    item.Total = item.UnitPrice * item.Quantity;
                    subtotal = subtotal + item.Total;
                }
                model.Total = subtotal;

                //5% tax
                model.Tax = Math.Round((model.Total * 5) / 100, 2);
                model.GrandTotal = model.Total + model.Tax;


            }

            return model;
        }

        public PagingListModel<OrderModel> GetOrderList(int page = 1, int pageSize = 10)
        {
            return _orderRepo.GetOrderList(page, pageSize);
        }

        public IEnumerable<Order> GetUserOrder(int UserId)
        {
            return _orderRepo.GetUserOrder(UserId);
        }

        public int PlaceOrder(int userId, string OrderId, string paymentId, CartModel cart, Address address)
        {
            Order order = new Order
            {
                PaymentId=paymentId,
                UserId=userId,
                CreatedDate=DateTime.Now,
                Id=OrderId,
                street=address.Street,
                Locality=address.Locality,
                City=address.City,
                ZipCode=address.ZipCode,
                PhoneNumber=address.PhoneNumber

            };

            foreach (var item in cart.Items)
            {
                OrderItem orderitem = new OrderItem(item.Id, item.UnitPrice, item.Quantity, item.Total);
                order.OrderItems.Add(orderitem);
            }
            _orderRepo.Add(order);
            return _orderRepo.SaveChanges();



        }
    }
}
