﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ePizzaHub.Services.Model
{
  public class RazorPayConfig
    {
        public string key { get; set; }

        public string Secret { get; set; }

    }
}
