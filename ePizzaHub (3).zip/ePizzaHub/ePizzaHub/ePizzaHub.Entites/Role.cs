﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity;

namespace ePizzaHub.Entites
{
   public class Role:IdentityRole<int>
    {

        //TO DO
    }
}
